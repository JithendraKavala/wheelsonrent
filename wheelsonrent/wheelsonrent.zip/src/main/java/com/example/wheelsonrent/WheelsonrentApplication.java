package com.example.wheelsonrent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WheelsonrentApplication {

	public static void main(String[] args) {
		SpringApplication.run(WheelsonrentApplication.class, args);
	}

}
