package com.example.wheelsonrent.entity;

public enum Role {
    RENTER, OWNER, ADMIN
}
