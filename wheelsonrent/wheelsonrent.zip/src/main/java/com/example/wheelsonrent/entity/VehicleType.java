package com.example.wheelsonrent.entity;

public enum VehicleType {
    BIKE,
    CAR
}
