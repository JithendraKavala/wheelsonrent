package com.example.wheelsonrent.entity;

public enum VehicleStatus {
    AVAILABLE,
    INACTIVE,
    MAINTENANCE,
    UNAVAILABLE,
    CHECKING
}