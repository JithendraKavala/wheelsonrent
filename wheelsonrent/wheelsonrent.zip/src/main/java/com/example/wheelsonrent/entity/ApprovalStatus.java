package com.example.wheelsonrent.entity;

public enum ApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED
}
