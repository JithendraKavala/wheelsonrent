package com.example.wheelsonrent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootTest
class WheelsonrentApplicationTests {

	@Test
	void contextLoads() {
	}

}
